/**
 * DO NOT MODIFY!
 */
package cmsc433.p5;

/**
 * The parameter on which to perform the map reduce.
 *
 */
public enum TrendingParameter {
	USER, TWEET, HASHTAG, HASHTAG_PAIR;
}
